user = input("Digite o nome de usuário: ")
password = input("Digite a senha: ")

if user == password:
    print("Erro: O nome de usuário e a senha não podem ser iguais.")
else:
    print("Login bem-sucedido!")